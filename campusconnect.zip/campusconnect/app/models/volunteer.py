from app.extensions import db
from app.utils import utcnow

APPLICATION_STATUSES = ("pending", "accepted", "waitlisted", "rejected", "withdrawn")


class VolunteerOpportunity(db.Model):
    __tablename__ = "volunteer_opportunities"
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey("events.id"), nullable=False, index=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    application_deadline = db.Column(db.DateTime, nullable=False)
    reporting_instructions = db.Column(db.Text)
    coordinator_info = db.Column(db.String(255))
    status = db.Column(db.String(20), nullable=False, default="open")
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    event = db.relationship("Event")
    roles = db.relationship("VolunteerRole", back_populates="opportunity", cascade="all, delete-orphan")


class VolunteerRole(db.Model):
    __tablename__ = "volunteer_roles"
    id = db.Column(db.Integer, primary_key=True)
    opportunity_id = db.Column(db.Integer, db.ForeignKey("volunteer_opportunities.id"), nullable=False, index=True)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text)
    positions = db.Column(db.Integer, nullable=False)
    required_skills = db.Column(db.Text)
    eligibility = db.Column(db.Text)

    opportunity = db.relationship("VolunteerOpportunity", back_populates="roles")
    shifts = db.relationship("VolunteerShift", back_populates="role", cascade="all, delete-orphan")
    __table_args__ = (db.CheckConstraint("positions > 0", name="ck_role_positions_positive"),)


class VolunteerShift(db.Model):
    __tablename__ = "volunteer_shifts"
    id = db.Column(db.Integer, primary_key=True)
    role_id = db.Column(db.Integer, db.ForeignKey("volunteer_roles.id"), nullable=False, index=True)
    start_at = db.Column(db.DateTime, nullable=False)
    end_at = db.Column(db.DateTime, nullable=False)
    location = db.Column(db.String(200))
    capacity = db.Column(db.Integer, nullable=False)

    role = db.relationship("VolunteerRole", back_populates="shifts")
    __table_args__ = (db.CheckConstraint("end_at > start_at", name="ck_shift_time_order"),)


class VolunteerApplication(db.Model):
    __tablename__ = "volunteer_applications"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    role_id = db.Column(db.Integer, db.ForeignKey("volunteer_roles.id"), nullable=False, index=True)
    preferred_shift_id = db.Column(db.Integer, db.ForeignKey("volunteer_shifts.id"))
    skills = db.Column(db.Text)
    experience = db.Column(db.Text)
    interests = db.Column(db.Text)
    availability = db.Column(db.Text)
    motivation = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), nullable=False, default="pending", index=True)
    decided_by = db.Column(db.Integer, db.ForeignKey("users.id"))
    decided_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    user = db.relationship("User", foreign_keys=[user_id])
    role = db.relationship("VolunteerRole")
    __table_args__ = (db.UniqueConstraint("user_id", "role_id", name="uq_application_user_role"),)


class VolunteerAssignment(db.Model):
    __tablename__ = "volunteer_assignments"
    id = db.Column(db.Integer, primary_key=True)
    application_id = db.Column(db.Integer, db.ForeignKey("volunteer_applications.id"), unique=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    role_id = db.Column(db.Integer, db.ForeignKey("volunteer_roles.id"), nullable=False)
    shift_id = db.Column(db.Integer, db.ForeignKey("volunteer_shifts.id"), nullable=False)
    assigned_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    __table_args__ = (db.UniqueConstraint("user_id", "shift_id", name="uq_assignment_user_shift"),)


class VolunteerAttendance(db.Model):
    __tablename__ = "volunteer_attendance"
    id = db.Column(db.Integer, primary_key=True)
    assignment_id = db.Column(db.Integer, db.ForeignKey("volunteer_assignments.id"), unique=True, nullable=False)
    check_in_at = db.Column(db.DateTime)
    check_out_at = db.Column(db.DateTime)
    verified_hours = db.Column(db.Numeric(5, 2))
    verification_status = db.Column(db.String(20), nullable=False, default="unverified")  # unverified/verified/corrected
    verified_by = db.Column(db.Integer, db.ForeignKey("users.id"))
    verified_at = db.Column(db.DateTime)
    __table_args__ = (db.CheckConstraint("check_out_at IS NULL OR check_in_at IS NULL OR check_out_at > check_in_at",
                                         name="ck_vol_attendance_time_order"),)


class Certificate(db.Model):
    __tablename__ = "certificates"
    id = db.Column(db.Integer, primary_key=True)
    reference = db.Column(db.String(40), unique=True, nullable=False)
    assignment_id = db.Column(db.Integer, db.ForeignKey("volunteer_assignments.id"), unique=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    event_id = db.Column(db.Integer, db.ForeignKey("events.id"), nullable=False)
    role_name = db.Column(db.String(120), nullable=False)
    hours = db.Column(db.Numeric(5, 2), nullable=False)
    issued_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    issued_at = db.Column(db.DateTime, default=utcnow, nullable=False)
