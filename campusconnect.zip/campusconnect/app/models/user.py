from werkzeug.security import generate_password_hash, check_password_hash
from app.extensions import db
from app.utils import utcnow

ROLE_STUDENT, ROLE_ORGANIZER, ROLE_ADMIN = "student", "organizer", "admin"


class College(db.Model):
    __tablename__ = "colleges"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), unique=True, nullable=False)


class Club(db.Model):
    __tablename__ = "clubs"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), unique=True, nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)


class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(190), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default=ROLE_STUDENT, index=True)
    is_active_account = db.Column(db.Boolean, nullable=False, default=True)
    college_id = db.Column(db.Integer, db.ForeignKey("colleges.id"))
    course = db.Column(db.String(120))
    year = db.Column(db.Integer)
    # Bumped on logout / suspension so previously issued session cookies stop working.
    session_version = db.Column(db.Integer, nullable=False, default=0)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    last_login_at = db.Column(db.DateTime)

    college = db.relationship("College")
    organizer_profile = db.relationship("OrganizerProfile", uselist=False,
                                        back_populates="user", foreign_keys="OrganizerProfile.user_id")

    def set_password(self, raw):
        self.password_hash = generate_password_hash(raw)  # scrypt by default

    def check_password(self, raw):
        return check_password_hash(self.password_hash, raw)

    @property
    def is_admin(self):
        return self.role == ROLE_ADMIN

    @property
    def is_approved_organizer(self):
        return (self.role == ROLE_ORGANIZER and self.organizer_profile is not None
                and self.organizer_profile.status == "approved")


class OrganizerProfile(db.Model):
    __tablename__ = "organizer_profiles"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), unique=True, nullable=False)
    club_id = db.Column(db.Integer, db.ForeignKey("clubs.id"))
    club_name = db.Column(db.String(160), nullable=False)
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), nullable=False, default="pending", index=True)  # pending/approved/rejected
    reviewed_by = db.Column(db.Integer, db.ForeignKey("users.id"))
    reviewed_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    user = db.relationship("User", back_populates="organizer_profile", foreign_keys=[user_id])
    club = db.relationship("Club")


class LoginAttempt(db.Model):
    """Failed-login log used for DB-backed throttling (works across worker processes)."""
    __tablename__ = "login_attempts"
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(190), nullable=False, index=True)
    ip = db.Column(db.String(64), nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False, index=True)
