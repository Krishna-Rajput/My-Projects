from app.extensions import db
from app.utils import utcnow

EVENT_STATUSES = ("draft", "pending", "published", "rejected", "cancelled")
REG_STATUSES = ("confirmed", "waitlisted", "cancelled", "attended")


class Category(db.Model):
    __tablename__ = "categories"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    slug = db.Column(db.String(80), unique=True, nullable=False)
    icon = db.Column(db.String(8), nullable=False, default="🎓")
    color = db.Column(db.String(9), nullable=False, default="#4f46e5")


class Event(db.Model):
    __tablename__ = "events"
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    poster_filename = db.Column(db.String(255))
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False, index=True)
    club_id = db.Column(db.Integer, db.ForeignKey("clubs.id"))
    organizer_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    venue = db.Column(db.String(200), nullable=False)
    start_at = db.Column(db.DateTime, nullable=False, index=True)
    end_at = db.Column(db.DateTime, nullable=False)
    registration_deadline = db.Column(db.DateTime, nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    eligibility = db.Column(db.Text)
    rules = db.Column(db.Text)
    registration_type = db.Column(db.String(10), nullable=False, default="free")  # paid reserved for later
    price_cents = db.Column(db.Integer, nullable=False, default=0)
    status = db.Column(db.String(20), nullable=False, default="draft", index=True)
    admin_feedback = db.Column(db.Text)
    is_demo = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=utcnow, onupdate=utcnow, nullable=False)

    category = db.relationship("Category")
    club = db.relationship("Club")
    organizer = db.relationship("User", foreign_keys=[organizer_id])

    __table_args__ = (db.CheckConstraint("capacity > 0", name="ck_event_capacity_positive"),)


class Registration(db.Model):
    __tablename__ = "event_registrations"
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey("events.id"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    status = db.Column(db.String(20), nullable=False, default="confirmed", index=True)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    cancelled_at = db.Column(db.DateTime)

    event = db.relationship("Event")
    user = db.relationship("User")
    ticket = db.relationship("Ticket", uselist=False, back_populates="registration")

    __table_args__ = (db.UniqueConstraint("event_id", "user_id", name="uq_registration_event_user"),)


class Ticket(db.Model):
    __tablename__ = "tickets"
    id = db.Column(db.Integer, primary_key=True)
    registration_id = db.Column(db.Integer, db.ForeignKey("event_registrations.id"), unique=True, nullable=False)
    reference = db.Column(db.String(64), unique=True, nullable=False)  # secrets.token_urlsafe
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    registration = db.relationship("Registration", back_populates="ticket")


class EventAttendance(db.Model):
    __tablename__ = "attendance_records"
    id = db.Column(db.Integer, primary_key=True)
    registration_id = db.Column(db.Integer, db.ForeignKey("event_registrations.id"), unique=True, nullable=False)
    checked_in_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    checked_in_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)


class SavedEvent(db.Model):
    __tablename__ = "saved_events"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey("events.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    __table_args__ = (db.UniqueConstraint("user_id", "event_id", name="uq_saved_user_event"),)
