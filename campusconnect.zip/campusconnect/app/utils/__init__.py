from datetime import datetime, timezone


def utcnow():
    """Naive UTC timestamp (portable across MySQL and SQLite)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)
