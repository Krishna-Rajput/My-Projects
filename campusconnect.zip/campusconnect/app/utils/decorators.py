from functools import wraps
from flask import g, redirect, url_for, request, abort, flash


def _login_endpoint():
    path = request.path
    if path.startswith("/admin"):
        return "auth.admin_login"
    if path.startswith("/organizer") or path.startswith("/dashboard/organizer"):
        return "auth.organizer_login"
    return "auth.login"


def login_required(view):
    @wraps(view)
    def wrapped(*a, **kw):
        if g.user is None:
            flash("Please sign in to continue.", "info")
            return redirect(url_for(_login_endpoint(), next=request.full_path.rstrip("?")))
        return view(*a, **kw)
    return wrapped


def roles_required(*roles):
    """Server-side role gate. Organizers must additionally be approved."""
    def deco(view):
        @wraps(view)
        @login_required
        def wrapped(*a, **kw):
            if g.user.role not in roles:
                abort(403)
            if g.user.role == "organizer" and not g.user.is_approved_organizer:
                return redirect(url_for("dashboard.organizer_pending"))
            return view(*a, **kw)
        return wrapped
    return deco


def safe_next(target):
    """Only allow same-site relative redirects (prevents open redirect)."""
    if target and target.startswith("/") and not target.startswith("//") and "\\" not in target:
        return target
    return None
