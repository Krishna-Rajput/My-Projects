"""CLI helpers. Usage: flask seed   (development only; creates clearly labelled DEMO data)."""
from datetime import timedelta
import secrets
import click
from app.extensions import db
from app.models import (User, College, Club, Category, Event, OrganizerProfile, ROLE_ADMIN, ROLE_ORGANIZER,
                        VolunteerOpportunity, VolunteerRole)
from app.utils import utcnow

DEMO_PASSWORD = "Demo@12345"

CATEGORIES = [("Hackathons", "hackathons", "💻", "#4f46e5"), ("Technical Workshops", "workshops", "🛠️", "#0891b2"),
              ("Cultural Fests", "cultural", "🎭", "#db2777"), ("Sports", "sports", "🏅", "#16a34a"),
              ("Seminars", "seminars", "🎤", "#d97706"), ("Competitions", "competitions", "🏆", "#7c3aed")]

EVENTS = [("HackNova 24-Hour Hackathon", "hackathons", "Innovation Lab, Block C", 5, 24, 150),
          ("Intro to Machine Learning with Python", "workshops", "Seminar Hall 2", 3, 3, 60),
          ("Spandan Annual Cultural Fest", "cultural", "Main Auditorium", 12, 8, 400),
          ("Inter-Department Cricket Cup", "sports", "College Ground", 8, 6, 120),
          ("Careers in Data Science: Industry Talk", "seminars", "Auditorium Hall A", 4, 2, 200),
          ("CodeSprint Competitive Programming Contest", "competitions", "Computer Lab 4", 6, 3, 80),
          ("Git & GitHub Essentials Workshop", "workshops", "Lab 2", 2, 2, 40),
          ("Open Mic Night", "cultural", "Amphitheatre", 9, 3, 100)]


def seed_volunteering(events):
    for ev in events:
        opp = VolunteerOpportunity(event_id=ev.id, title=f"{ev.title}: volunteer crew (DEMO)",
                                   description="[DEMO] Help the organizing team run this event smoothly.",
                                   application_deadline=ev.start_at - timedelta(hours=12),
                                   reporting_instructions="Report to the registration desk 30 minutes before start.",
                                   coordinator_info="Demo Organizer, organizer@campusconnect.local")
        db.session.add(opp)
        db.session.flush()
        for name, n, skills in (("Registration Desk", 3, "Friendly, organised"), ("Technical Support", 2, "Basic troubleshooting"),
                                ("Hospitality", 4, None)):
            db.session.add(VolunteerRole(opportunity_id=opp.id, name=name, positions=n, required_skills=skills,
                                         description=f"{name} support during the event."))


def register(app):
    @app.cli.command("seed")
    def seed():
        """Seed demo categories, accounts and events. In production, demo passwords are random."""
        prod = app.config["ENV_NAME"] == "production"
        issued = {}
        if User.query.filter_by(email="admin@campusconnect.local").first():
            click.echo("Already seeded.")
            return
        college = College(name="Demo Institute of Technology")
        db.session.add(college)
        for n, s, i, c in CATEGORIES:
            db.session.add(Category(name=n, slug=s, icon=i, color=c))
        club = Club(name="Tech Club (DEMO)", description="Demo club for local development.")
        db.session.add(club)
        db.session.flush()

        def mk(name, email, role):
            u = User(name=name, email=email, role=role, college=college, course="B.Tech CSE", year=3)
            pw = secrets.token_urlsafe(12) if prod else DEMO_PASSWORD
            issued[email] = pw
            u.set_password(pw)
            db.session.add(u)
            db.session.flush()
            return u

        if not prod:
            mk("Demo Admin", "admin@campusconnect.local", ROLE_ADMIN)
        org = mk("Demo Organizer", "organizer@campusconnect.local", ROLE_ORGANIZER)
        db.session.add(OrganizerProfile(user_id=org.id, club_id=club.id, club_name=club.name,
                                        reason="Seeded demo organizer.", status="approved", reviewed_at=utcnow()))
        mk("Demo Student", "student@campusconnect.local", "student")
        cats = {c.slug: c for c in Category.query.all()}
        now = utcnow()
        for title, slug, venue, days, hours, cap in EVENTS:
            start = (now + timedelta(days=days)).replace(hour=10, minute=0, second=0, microsecond=0)
            db.session.add(Event(
                title=title, category_id=cats[slug].id, club_id=club.id, organizer_id=org.id, venue=venue,
                description=f"[DEMO EVENT] Sample description for “{title}”. Seeded for local development only.",
                start_at=start, end_at=start + timedelta(hours=hours), registration_deadline=start - timedelta(days=1),
                capacity=cap, eligibility="Open to all students.", rules="Carry your college ID card.",
                status="published", is_demo=True))
        db.session.flush()
        seed_volunteering(Event.query.order_by(Event.start_at).limit(3).all())
        db.session.commit()
        if prod:
            click.echo("Seeded demo events. Random one-time demo passwords (save them now):")
            for e, pw in issued.items():
                click.echo(f"  {e}  {pw}")
            click.echo("Create your real admin with: flask create-admin")
            return
        click.echo(f"Seeded. Demo logins (password '{DEMO_PASSWORD}'): admin@/organizer@/student@campusconnect.local")


    @app.cli.command("create-admin")
    @click.option("--email", prompt=True)
    @click.option("--name", prompt=True)
    @click.password_option()
    def create_admin(email, name, password):
        """Create an administrator account (admins cannot self-register)."""
        email = email.strip().lower()
        if User.query.filter_by(email=email).first():
            raise click.ClickException("That email already exists.")
        u = User(name=name.strip(), email=email, role=ROLE_ADMIN, course="-", year=1)
        u.set_password(password)
        db.session.add(u)
        db.session.commit()
        click.echo(f"Admin {email} created.")
