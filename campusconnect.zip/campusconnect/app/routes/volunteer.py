from flask import Blueprint, render_template, redirect, url_for, flash, request, abort, g
from sqlalchemy import or_
from app.extensions import db
from app.forms.volunteer import OpportunityForm, RoleForm, ApplyForm
from app.models import (Event, Category, VolunteerOpportunity, VolunteerRole, VolunteerApplication)
from app.services import volunteer_service as svc
from app.utils import utcnow
from app.utils.decorators import roles_required

bp = Blueprint("volunteer", __name__, url_prefix="/volunteer")
org_bp = Blueprint("volunteer_org", __name__, url_prefix="/organizer/volunteer")


# ---------- student / public ----------
@bp.route("/")
def index():
    q = (request.args.get("q") or "").strip()[:100]
    cat = (request.args.get("category") or "").strip()
    page = max(request.args.get("page", 1, type=int), 1)
    now = utcnow()
    query = (VolunteerOpportunity.query.join(Event, VolunteerOpportunity.event_id == Event.id)
             .filter(VolunteerOpportunity.status == "open", VolunteerOpportunity.application_deadline >= now,
                     Event.status == "published", Event.end_at >= now))
    if q:
        like = f"%{q}%"
        role_match = db.session.query(VolunteerRole.opportunity_id).filter(VolunteerRole.name.ilike(like))
        query = query.filter(or_(VolunteerOpportunity.title.ilike(like), Event.title.ilike(like),
                                 VolunteerOpportunity.description.ilike(like), VolunteerOpportunity.id.in_(role_match)))
    if cat:
        query = query.join(Category, Event.category_id == Category.id).filter(Category.slug == cat)
    pagination = query.order_by(VolunteerOpportunity.application_deadline).paginate(page=page, per_page=6, error_out=False)
    mine = {}
    if g.user and g.user.role == "student":
        mine = {a.role_id: a.status for a in VolunteerApplication.query.filter_by(user_id=g.user.id)}
    return render_template("volunteer/index.html", pagination=pagination, q=q, cat=cat, filled=svc.accepted_counts(),
                           mine=mine, categories=Category.query.order_by(Category.name).all())


@bp.route("/roles/<int:role_id>/apply", methods=["GET", "POST"])
@roles_required("student")
def apply(role_id):
    role = db.session.get(VolunteerRole, role_id) or abort(404)
    if role.opportunity.event.status != "published":
        abort(404)
    form = ApplyForm()
    if form.validate_on_submit():
        try:
            svc.apply(g.user, role, {k: getattr(form, k).data for k in
                                     ("skills", "experience", "interests", "availability", "motivation")})
        except svc.VolunteerError as e:
            flash(str(e), "error")
        else:
            flash("Application submitted. You'll be notified of the decision.", "success")
            return redirect(url_for("volunteer.my_applications"))
    return render_template("volunteer/apply.html", form=form, role=role, filled=svc.accepted_count(role.id))


@bp.route("/my-applications")
@roles_required("student")
def my_applications():
    apps = (VolunteerApplication.query.filter_by(user_id=g.user.id)
            .order_by(VolunteerApplication.created_at.desc()).all())
    return render_template("volunteer/my_applications.html", apps=apps, now=utcnow())


@bp.route("/applications/<int:app_id>/withdraw", methods=["POST"])
@roles_required("student")
def withdraw(app_id):
    application = db.session.get(VolunteerApplication, app_id)
    if not application or application.user_id != g.user.id:
        abort(404)  # IDOR guard: other users' records look nonexistent
    try:
        svc.withdraw(g.user, application)
        flash("Application withdrawn.", "success")
    except svc.VolunteerError as e:
        flash(str(e), "error")
    return redirect(url_for("volunteer.my_applications"))


# ---------- organizer ----------
def _own_opportunity(opp_id):
    opp = db.session.get(VolunteerOpportunity, opp_id)
    if not opp or opp.event.organizer_id != g.user.id:
        abort(404)
    return opp


@org_bp.route("/")
@roles_required("organizer")
def manage_list():
    opps = (VolunteerOpportunity.query.join(Event, VolunteerOpportunity.event_id == Event.id)
            .filter(Event.organizer_id == g.user.id).order_by(VolunteerOpportunity.created_at.desc()).all())
    filled = svc.accepted_counts()
    return render_template("volunteer/manage_list.html", opps=opps, filled=filled)


@org_bp.route("/new", methods=["GET", "POST"])
@roles_required("organizer")
def new_opportunity():
    events = (Event.query.filter(Event.organizer_id == g.user.id, Event.status == "published", Event.end_at >= utcnow())
              .order_by(Event.start_at).all())
    form = OpportunityForm()
    form.event_id.choices = [(e.id, e.title) for e in events]
    if form.validate_on_submit():
        event = next((e for e in events if e.id == form.event_id.data), None)
        if not event:
            abort(404)
        if form.application_deadline.data > event.end_at:
            form.application_deadline.errors.append("Deadline must be before the event ends.")
        else:
            opp = VolunteerOpportunity(event_id=event.id, title=form.title.data.strip(), description=form.description.data.strip(),
                                       application_deadline=form.application_deadline.data,
                                       reporting_instructions=form.reporting_instructions.data,
                                       coordinator_info=form.coordinator_info.data)
            db.session.add(opp)
            db.session.commit()
            flash("Opportunity created. Now add the volunteer roles.", "success")
            return redirect(url_for("volunteer_org.detail", opp_id=opp.id))
    return render_template("volunteer/opportunity_form.html", form=form, no_events=not events)


@org_bp.route("/<int:opp_id>")
@roles_required("organizer")
def detail(opp_id):
    opp = _own_opportunity(opp_id)
    role_ids = [r.id for r in opp.roles]
    apps = []
    if role_ids:
        apps = (VolunteerApplication.query.filter(VolunteerApplication.role_id.in_(role_ids))
                .order_by(VolunteerApplication.created_at).all())
    return render_template("volunteer/manage_detail.html", opp=opp, apps=apps, filled=svc.accepted_counts(), form=RoleForm())


@org_bp.route("/<int:opp_id>/roles", methods=["POST"])
@roles_required("organizer")
def add_role(opp_id):
    opp = _own_opportunity(opp_id)
    form = RoleForm()
    if form.validate_on_submit():
        db.session.add(VolunteerRole(opportunity_id=opp.id, name=form.name.data.strip(), positions=form.positions.data,
                                     description=form.description.data, required_skills=form.required_skills.data,
                                     eligibility=form.eligibility.data))
        db.session.commit()
        flash("Role added.", "success")
    else:
        flash("Could not add role: " + "; ".join(f"{k}: {', '.join(v)}" for k, v in form.errors.items()), "error")
    return redirect(url_for("volunteer_org.detail", opp_id=opp.id))


@org_bp.route("/applications/<int:app_id>/decision", methods=["POST"])
@roles_required("organizer")
def decision(app_id):
    application = db.session.get(VolunteerApplication, app_id) or abort(404)
    opp = _own_opportunity(application.role.opportunity_id)
    try:
        svc.decide(application, request.form.get("decision"), g.user)
        flash("Decision saved and the volunteer was notified.", "success")
    except svc.VolunteerError as e:
        flash(str(e), "error")
    return redirect(url_for("volunteer_org.detail", opp_id=opp.id))
