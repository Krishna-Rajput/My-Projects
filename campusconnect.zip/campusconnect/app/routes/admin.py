from flask import Blueprint, render_template, redirect, url_for, flash, request, abort, g
from sqlalchemy import or_, func
from app.extensions import db
from app.models import (User, Event, Registration, OrganizerProfile, Club, AuditLog, VolunteerApplication,
                        VolunteerAttendance, ROLE_STUDENT)
from app.services.audit import log_action
from app.services.notifications import notify
from app.utils import utcnow
from app.utils.decorators import roles_required

bp = Blueprint("admin", __name__, url_prefix="/admin")


@bp.route("/")
@roles_required("admin")
def overview():
    hours = db.session.query(func.coalesce(func.sum(VolunteerAttendance.verified_hours), 0)).filter(
        VolunteerAttendance.verification_status.in_(["verified", "corrected"])).scalar()
    stats = {
        "students": User.query.filter_by(role=ROLE_STUDENT).count(),
        "organizers": OrganizerProfile.query.filter_by(status="approved").count(),
        "events": Event.query.count(),
        "upcoming": Event.query.filter(Event.status == "published", Event.start_at >= utcnow()).count(),
        "pending_events": Event.query.filter_by(status="pending").count(),
        "pending_organizers": OrganizerProfile.query.filter_by(status="pending").count(),
        "registrations": Registration.query.filter(Registration.status != "cancelled").count(),
        "applications": VolunteerApplication.query.count(),
        "hours": float(hours or 0),
    }
    return render_template("admin/overview.html", stats=stats)


@bp.route("/organizers")
@roles_required("admin")
def organizers():
    status = request.args.get("status", "pending")
    if status not in ("pending", "approved", "rejected"):
        status = "pending"
    rows = (OrganizerProfile.query.filter_by(status=status).join(User, OrganizerProfile.user_id == User.id)
            .order_by(OrganizerProfile.created_at.desc()).all())
    return render_template("admin/organizers.html", rows=rows, status=status)


@bp.route("/organizers/<int:profile_id>/decision", methods=["POST"])
@roles_required("admin")
def organizer_decision(profile_id):
    profile = db.session.get(OrganizerProfile, profile_id) or abort(404)
    decision = request.form.get("decision")
    if decision not in ("approve", "reject"):
        abort(400)
    if profile.status != "pending":
        flash("This application has already been decided.", "info")
        return redirect(url_for("admin.organizers"))
    if decision == "approve":
        club = Club.query.filter(func.lower(Club.name) == profile.club_name.lower()).first()
        if not club:
            club = Club(name=profile.club_name)
            db.session.add(club)
            db.session.flush()
        profile.club_id, profile.status = club.id, "approved"
    else:
        profile.status = "rejected"
    profile.reviewed_by, profile.reviewed_at = g.user.id, utcnow()
    log_action(g.user, f"organizer_{decision}d", "organizer_profile", profile.id, f"user_id={profile.user_id}")
    notify(profile.user_id, "organizer_decision", f"Organizer application {profile.status}",
           "You can now create events." if decision == "approve" else "Contact the administrators for details.",
           url_for("dashboard.index"))
    db.session.commit()
    flash(f"Application {profile.status}.", "success")
    return redirect(url_for("admin.organizers"))


@bp.route("/users")
@roles_required("admin")
def users():
    q = (request.args.get("q") or "").strip()[:100]
    page = max(request.args.get("page", 1, type=int), 1)
    query = User.query
    if q:
        like = f"%{q}%"
        query = query.filter(or_(User.name.ilike(like), User.email.ilike(like)))
    pagination = query.order_by(User.created_at.desc()).paginate(page=page, per_page=15, error_out=False)
    return render_template("admin/users.html", pagination=pagination, q=q)


@bp.route("/users/<int:user_id>/toggle-active", methods=["POST"])
@roles_required("admin")
def toggle_active(user_id):
    user = db.session.get(User, user_id) or abort(404)
    if user.id == g.user.id:
        flash("You cannot suspend your own account.", "error")
        return redirect(url_for("admin.users"))
    user.is_active_account = not user.is_active_account
    user.session_version += 1  # kicks out any live sessions immediately
    log_action(g.user, "user_restored" if user.is_active_account else "user_suspended", "user", user.id, user.email)
    db.session.commit()
    flash(f"{user.name} {'restored' if user.is_active_account else 'suspended'}.", "success")
    return redirect(request.referrer or url_for("admin.users"))


@bp.route("/audit-logs")
@roles_required("admin")
def audit_logs():
    page = max(request.args.get("page", 1, type=int), 1)
    pagination = AuditLog.query.order_by(AuditLog.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template("admin/audit_logs.html", pagination=pagination)
