from flask import Blueprint, render_template, redirect, url_for, flash, g
from app.extensions import db
from app.forms.auth import ProfileForm
from app.models import Event, Registration, Notification, VolunteerApplication
from app.services import volunteer_service
from app.services.auth_service import get_or_create_college
from app.utils.decorators import login_required, roles_required

bp = Blueprint("dashboard", __name__)


@bp.route("/dashboard")
@login_required
def index():
    if g.user.role == "admin":
        return redirect(url_for("admin.overview"))
    if g.user.role == "organizer":
        return redirect(url_for("dashboard.organizer"))
    return redirect(url_for("dashboard.student"))


@bp.route("/dashboard/student")
@roles_required("student")
def student():
    regs = (Registration.query.filter(Registration.user_id == g.user.id, Registration.status.in_(["confirmed", "waitlisted"]))
            .join(Event).order_by(Event.start_at).limit(5).all())
    notes = Notification.query.filter_by(user_id=g.user.id).order_by(Notification.created_at.desc()).limit(5).all()
    va = VolunteerApplication.query.filter_by(user_id=g.user.id)
    stats = {"registrations": Registration.query.filter_by(user_id=g.user.id).filter(Registration.status != "cancelled").count(),
             "vol_pending": va.filter_by(status="pending").count(), "vol_accepted": va.filter_by(status="accepted").count()}
    return render_template("dashboard/student.html", regs=regs, notes=notes, stats=stats)


@bp.route("/dashboard/organizer")
@roles_required("organizer")
def organizer():
    base = Event.query.filter_by(organizer_id=g.user.id)
    stats = {
        "total": base.count(),
        "published": base.filter_by(status="published").count(),
        "pending": base.filter_by(status="pending").count(),
        **{"vol_" + k: v for k, v in volunteer_service.organizer_stats(g.user.id).items()},
    }
    return render_template("dashboard/organizer.html", stats=stats)


@bp.route("/dashboard/organizer/pending")
@login_required
def organizer_pending():
    profile = g.user.organizer_profile
    if g.user.role != "organizer" or (profile and profile.status == "approved"):
        return redirect(url_for("dashboard.index"))
    return render_template("dashboard/organizer_pending.html", profile=profile)


@bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    u = g.user
    form = ProfileForm(name=u.name, college=u.college.name if u.college else "", course=u.course, year=str(u.year or 1))
    if form.validate_on_submit():
        u.name = form.name.data.strip()
        u.course = form.course.data.strip()
        u.year = int(form.year.data)
        u.college = get_or_create_college(form.college.data)
        db.session.commit()
        flash("Profile updated.", "success")
        return redirect(url_for("dashboard.profile"))
    return render_template("dashboard/profile.html", form=form)
