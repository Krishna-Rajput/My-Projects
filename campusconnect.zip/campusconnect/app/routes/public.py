from datetime import datetime
from flask import Blueprint, render_template, request, abort
from sqlalchemy import func, or_
from app.extensions import db
from app.models import Event, Category, User, Registration, ROLE_STUDENT, OrganizerProfile
from app.utils import utcnow

bp = Blueprint("public", __name__)


def _published_upcoming():
    return Event.query.filter(Event.status == "published", Event.end_at >= utcnow())


@bp.route("/")
def home():
    featured = _published_upcoming().order_by(Event.start_at).limit(6).all()
    categories = Category.query.order_by(Category.name).all()
    stats = {
        "students": User.query.filter_by(role=ROLE_STUDENT, is_active_account=True).count(),
        "organizers": OrganizerProfile.query.filter_by(status="approved").count(),
        "events": Event.query.filter_by(status="published").count(),
        "registrations": Registration.query.filter(Registration.status != "cancelled").count(),
    }
    return render_template("public/home.html", featured=featured, categories=categories, stats=stats)


@bp.route("/events")
def events():
    q = (request.args.get("q") or "").strip()[:100]
    cat = (request.args.get("category") or "").strip()
    page = max(request.args.get("page", 1, type=int), 1)
    query = _published_upcoming()
    if q:
        like = f"%{q}%"
        query = query.filter(or_(Event.title.ilike(like), Event.description.ilike(like), Event.venue.ilike(like)))
    if cat:
        query = query.join(Category).filter(Category.slug == cat)
    pagination = query.order_by(Event.start_at).paginate(page=page, per_page=9, error_out=False)
    return render_template("public/events.html", pagination=pagination, q=q, cat=cat,
                           categories=Category.query.order_by(Category.name).all())


@bp.route("/events/<int:event_id>")
def event_detail(event_id):
    event = db.session.get(Event, event_id)
    if not event or event.status not in ("published", "cancelled"):
        abort(404)
    return render_template("public/event_detail.html", event=event)


@bp.route("/about")
def about():
    return render_template("public/about.html")


@bp.route("/help")
def help_page():
    return render_template("public/help.html")


@bp.route("/privacy")
def privacy():
    return render_template("public/privacy.html")


@bp.route("/terms")
def terms():
    return render_template("public/terms.html")
