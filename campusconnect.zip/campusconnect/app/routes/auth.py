from flask import Blueprint, render_template, redirect, url_for, flash, request, g
from app.extensions import db
from app.forms.auth import LoginForm, StudentRegisterForm, OrganizerApplyForm
from app.services import auth_service as svc
from app.utils.decorators import login_required, safe_next

bp = Blueprint("auth", __name__)


def _home_for(user):
    return url_for("dashboard.index")


def _portal_login(role, title, subtitle):
    if g.user:
        return redirect(_home_for(g.user))
    form = LoginForm()
    if form.validate_on_submit():
        try:
            user = svc.authenticate(form.email.data, form.password.data, request.remote_addr or "unknown", role=role)
        except svc.AuthError as e:
            flash(str(e), "error")
        else:
            svc.start_session(user)
            flash(f"Welcome back, {user.name.split()[0]}!", "success")
            return redirect(safe_next(request.args.get("next")) or _home_for(user))
    return render_template("auth/login.html", form=form, portal=role, title=title, subtitle=subtitle)


@bp.route("/login", methods=["GET", "POST"])
def login():
    return _portal_login("student", "Student sign in", "Browse events, register and volunteer.")


@bp.route("/organizer/login", methods=["GET", "POST"])
def organizer_login():
    return _portal_login("organizer", "Organizer portal", "Manage your events and volunteer teams.")


@bp.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    return _portal_login("admin", "Administrator portal", "Authorised platform administrators only.")


@bp.route("/logout", methods=["POST"])
@login_required
def logout():
    svc.end_session(g.user)
    flash("You have been signed out.", "info")
    return redirect(url_for("public.home"))


def _account_kwargs(form):
    return dict(name=form.name.data, email=form.email.data, password=form.password.data,
                college=form.college.data, course=form.course.data, year=int(form.year.data))


@bp.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(_home_for(g.user))
    form = StudentRegisterForm()
    if form.validate_on_submit():
        try:
            user = svc.register_user(**_account_kwargs(form))
            db.session.commit()
        except svc.AuthError as e:
            db.session.rollback()
            form.email.errors.append(str(e))
        else:
            svc.start_session(user)
            flash("Your account has been created. Welcome to CampusConnect!", "success")
            return redirect(url_for("dashboard.index"))
    return render_template("auth/register.html", form=form)


@bp.route("/organizer-application", methods=["GET", "POST"])
def organizer_apply():
    if g.user:
        return redirect(_home_for(g.user))
    form = OrganizerApplyForm()
    if form.validate_on_submit():
        try:
            user = svc.apply_organizer(club_name=form.club_name.data, reason=form.reason.data,
                                       **_account_kwargs(form))
            db.session.commit()
        except svc.AuthError as e:
            db.session.rollback()
            form.email.errors.append(str(e))
        else:
            svc.start_session(user)
            flash("Application submitted. An administrator will review it.", "success")
            return redirect(url_for("dashboard.index"))
    return render_template("auth/organizer_apply.html", form=form)
