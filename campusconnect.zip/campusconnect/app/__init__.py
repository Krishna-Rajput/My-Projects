import logging
from flask import Flask, g, render_template
from config import Config
from app.extensions import db, migrate, csrf
from app.services.auth_service import load_session_user


def create_app(config_object=Config):
    app = Flask(__name__)
    app.config.from_object(config_object)

    if not app.config.get("SECRET_KEY"):
        raise RuntimeError("SECRET_KEY is not set. Copy .env.example to .env and set it.")
    if not app.config.get("SQLALCHEMY_DATABASE_URI"):
        raise RuntimeError("DATABASE_URL is not set. See .env.example.")

    if app.config.get("ENV_NAME") == "production":
        from werkzeug.middleware.proxy_fix import ProxyFix
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)  # real client IP + https behind host proxy

    db.init_app(app)
    migrate.init_app(app, db)
    csrf.init_app(app)

    from app import models  # noqa: F401  (register tables with metadata)
    from app.routes import public, auth, dashboard, admin, volunteer
    for bp in (public.bp, auth.bp, dashboard.bp, admin.bp, volunteer.bp, volunteer.org_bp):
        app.register_blueprint(bp)

    @app.before_request
    def _load_user():
        g.user = load_session_user()

    @app.context_processor
    def _inject():
        unread = 0
        if g.get("user"):
            from app.models import Notification
            unread = Notification.query.filter_by(user_id=g.user.id, is_read=False).count()
        return {"current_user": g.get("user"), "unread_count": unread}

    @app.after_request
    def _headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        return resp

    for code, title, msg in ((403, "Access denied", "You do not have permission to view this page."),
                             (404, "Page not found", "We couldn't find what you were looking for."),
                             (413, "File too large", "That upload exceeds the 2 MB limit."),
                             (429, "Slow down", "Too many requests. Please try again shortly.")):
        app.register_error_handler(code, _make_handler(code, title, msg))

    @app.errorhandler(500)
    def _500(err):
        db.session.rollback()
        app.logger.exception("Unhandled error")
        return render_template("errors/error.html", code=500, title="Something went wrong",
                               message="An unexpected error occurred. It has been logged."), 500

    from app import cli
    cli.register(app)
    logging.basicConfig(level=logging.INFO)
    return app


def _make_handler(code, title, msg):
    def handler(err):
        return render_template("errors/error.html", code=code, title=title, message=msg), code
    return handler
