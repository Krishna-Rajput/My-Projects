from app.extensions import db
from app.models import AuditLog


def log_action(actor, action, target_type, target_id=None, details=None):
    """Add an audit row to the current session; caller commits (same transaction as the action)."""
    db.session.add(AuditLog(actor_id=getattr(actor, "id", None), action=action,
                            target_type=target_type, target_id=target_id, details=details))
