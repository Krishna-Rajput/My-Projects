from datetime import timedelta
from flask import session, current_app
from werkzeug.security import check_password_hash, generate_password_hash
from sqlalchemy import func
from app.extensions import db
from app.models import (User, College, OrganizerProfile, LoginAttempt, ROLE_STUDENT, ROLE_ORGANIZER)
from app.utils import utcnow

_DUMMY_HASH = generate_password_hash("not-a-real-password")


class AuthError(Exception):
    pass


def get_or_create_college(name):
    name = " ".join(name.split())
    college = College.query.filter(func.lower(College.name) == name.lower()).first()
    if not college:
        college = College(name=name)
        db.session.add(college)
        db.session.flush()
    return college


def email_taken(email):
    return User.query.filter_by(email=email.lower()).first() is not None


def register_user(*, name, email, password, college, course, year, role=ROLE_STUDENT):
    email = email.strip().lower()
    if email_taken(email):
        raise AuthError("An account with this email already exists.")
    user = User(name=name.strip(), email=email, role=role, course=course.strip(), year=year,
                college=get_or_create_college(college))
    user.set_password(password)
    db.session.add(user)
    db.session.flush()
    return user


def apply_organizer(*, club_name, reason, **user_fields):
    user = register_user(role=ROLE_ORGANIZER, **user_fields)
    db.session.add(OrganizerProfile(user_id=user.id, club_name=club_name.strip(), reason=reason.strip()))
    return user


def _recent_failures(email, ip):
    since = utcnow() - timedelta(minutes=current_app.config["LOGIN_WINDOW_MINUTES"])
    q = LoginAttempt.query.filter(LoginAttempt.created_at >= since)
    return q.filter_by(email=email, ip=ip).count(), q.filter_by(ip=ip).count()


def authenticate(email, password, ip, role=None):
    email = (email or "").strip().lower()
    limit = current_app.config["LOGIN_MAX_FAILURES"]
    pair, per_ip = _recent_failures(email, ip)
    if pair >= limit or per_ip >= limit * 4:
        raise AuthError("Too many failed attempts. Please wait a few minutes and try again.")
    user = User.query.filter_by(email=email).first()
    ok = check_password_hash(user.password_hash if user else _DUMMY_HASH, password or "")
    if not (user and ok):
        db.session.add(LoginAttempt(email=email[:190], ip=ip))
        db.session.commit()
        raise AuthError("Incorrect email or password.")
    if not user.is_active_account:
        raise AuthError("This account has been suspended. Please contact the administrators.")
    if role and user.role != role:
        raise AuthError(f"This is a {user.role} account. Please use the {user.role} sign-in portal.")
    LoginAttempt.query.filter_by(email=email, ip=ip).delete()
    user.last_login_at = utcnow()
    db.session.commit()
    return user


def start_session(user):
    session.clear()
    session.permanent = True
    session["uid"] = user.id
    session["sv"] = user.session_version


def end_session(user=None):
    """Invalidate server-side: bump session_version so a copied cookie no longer works."""
    if user is not None:
        user.session_version += 1
        db.session.commit()
    session.clear()


def load_session_user():
    uid = session.get("uid")
    if not uid:
        return None
    user = db.session.get(User, uid)
    if not user or not user.is_active_account or user.session_version != session.get("sv"):
        session.clear()
        return None
    return user
