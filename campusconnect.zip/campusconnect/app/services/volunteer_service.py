from sqlalchemy import func
from sqlalchemy.exc import IntegrityError
from app.extensions import db
from app.models import (VolunteerApplication, VolunteerRole, VolunteerOpportunity, Event)
from app.services.notifications import notify
from app.services.audit import log_action
from app.utils import utcnow

ACTIVE = ("pending", "accepted", "waitlisted")
DECISIONS = {"accept": "accepted", "waitlist": "waitlisted", "reject": "rejected"}


class VolunteerError(Exception):
    pass


def accepted_counts():
    rows = (db.session.query(VolunteerApplication.role_id, func.count())
            .filter(VolunteerApplication.status == "accepted").group_by(VolunteerApplication.role_id).all())
    return dict(rows)


def accepted_count(role_id):
    return VolunteerApplication.query.filter_by(role_id=role_id, status="accepted").count()


def apply(user, role, data):
    opp, event, now = role.opportunity, role.opportunity.event, utcnow()
    if opp.status != "open" or event.status != "published" or event.end_at < now:
        raise VolunteerError("This opportunity is closed.")
    if now > opp.application_deadline:
        raise VolunteerError("The application deadline has passed.")
    existing = VolunteerApplication.query.filter_by(user_id=user.id, role_id=role.id).first()
    if existing and existing.status != "withdrawn":
        raise VolunteerError("You have already applied for this role.")
    if existing:  # re-apply after withdrawing
        for k, v in data.items():
            setattr(existing, k, v)
        existing.status, existing.decided_by, existing.decided_at = "pending", None, None
        application = existing
    else:
        application = VolunteerApplication(user_id=user.id, role_id=role.id, status="pending", **data)
        db.session.add(application)
    try:
        db.session.flush()
    except IntegrityError:  # concurrent duplicate submit
        db.session.rollback()
        raise VolunteerError("You have already applied for this role.")
    notify(event.organizer_id, "volunteer_application", "New volunteer application",
           f"{user.name} applied for {role.name} at {event.title}.", f"/organizer/volunteer/{opp.id}")
    db.session.commit()
    return application


def withdraw(user, application):
    if application.user_id != user.id:
        raise VolunteerError("Not your application.")
    if application.status not in ACTIVE:
        raise VolunteerError("This application can no longer be withdrawn.")
    if utcnow() > application.role.opportunity.application_deadline:
        raise VolunteerError("The deadline has passed, so this application can no longer be withdrawn.")
    application.status = "withdrawn"
    db.session.commit()


def decide(application, decision, organizer):
    """Organizer decision. Locks the role row so two organizers can't overfill positions."""
    if decision not in DECISIONS:
        raise VolunteerError("Invalid decision.")
    if application.status == "withdrawn":
        raise VolunteerError("The applicant withdrew this application.")
    role = db.session.query(VolunteerRole).filter_by(id=application.role_id).with_for_update().one()
    new_status = DECISIONS[decision]
    if new_status == "accepted" and application.status != "accepted" and accepted_count(role.id) >= role.positions:
        db.session.rollback()
        raise VolunteerError("All positions for this role are filled. Waitlist the applicant instead.")
    application.status, application.decided_by, application.decided_at = new_status, organizer.id, utcnow()
    event = role.opportunity.event
    notify(application.user_id, "volunteer_decision", f"Volunteer application {new_status}",
           f"Your application for {role.name} at {event.title} was {new_status}.", "/volunteer/my-applications")
    log_action(organizer, f"volunteer_{new_status}", "volunteer_application", application.id)
    db.session.commit()


def organizer_stats(user_id):
    base = (db.session.query(VolunteerRole).join(VolunteerOpportunity).join(Event, VolunteerOpportunity.event_id == Event.id)
            .filter(Event.organizer_id == user_id))
    positions = sum(r.positions for r in base.all())
    role_ids = [r.id for r in base.all()]
    filled = pending = 0
    if role_ids:
        q = VolunteerApplication.query.filter(VolunteerApplication.role_id.in_(role_ids))
        filled = q.filter_by(status="accepted").count()
        pending = q.filter_by(status="pending").count()
    return {"positions": positions, "filled": filled, "pending": pending}
