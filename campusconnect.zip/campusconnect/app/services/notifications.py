from app.extensions import db
from app.models import Notification


def notify(user_id, kind, title, body=None, link=None):
    """Create an in-app notification (caller commits). Email/SMS are not sent unless configured."""
    db.session.add(Notification(user_id=user_id, kind=kind, title=title, body=body, link=link))
