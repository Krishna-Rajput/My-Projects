import re
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SelectField, TextAreaField
from wtforms.validators import DataRequired, Email, Length, EqualTo, ValidationError


def strong_password(form, field):
    pw = field.data or ""
    if not (re.search(r"[A-Za-z]", pw) and re.search(r"\d", pw)):
        raise ValidationError("Use at least one letter and one number.")


YEARS = [(str(i), f"Year {i}") for i in range(1, 7)]


class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email(), Length(max=190)])
    password = PasswordField("Password", validators=[DataRequired()])


class _AccountFields:
    name = StringField("Full name", validators=[DataRequired(), Length(min=2, max=120)])
    email = StringField("College email", validators=[DataRequired(), Email(), Length(max=190)])
    college = StringField("College", validators=[DataRequired(), Length(max=160)])
    course = StringField("Course / branch", validators=[DataRequired(), Length(max=120)])
    year = SelectField("Year", choices=YEARS, validators=[DataRequired()])
    password = PasswordField("Password", validators=[DataRequired(), Length(min=8, max=128), strong_password])
    confirm = PasswordField("Confirm password", validators=[DataRequired(), EqualTo("password", "Passwords must match.")])


class StudentRegisterForm(FlaskForm, _AccountFields):
    pass


class OrganizerApplyForm(FlaskForm, _AccountFields):
    club_name = StringField("Club / organisation", validators=[DataRequired(), Length(max=160)])
    reason = TextAreaField("Why do you want to organise events?", validators=[DataRequired(), Length(min=20, max=1500)])


class ProfileForm(FlaskForm):
    name = StringField("Full name", validators=[DataRequired(), Length(min=2, max=120)])
    college = StringField("College", validators=[DataRequired(), Length(max=160)])
    course = StringField("Course / branch", validators=[DataRequired(), Length(max=120)])
    year = SelectField("Year", choices=YEARS, validators=[DataRequired()])
