from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, IntegerField, DateTimeLocalField
from wtforms.validators import DataRequired, Length, NumberRange, Optional


class OpportunityForm(FlaskForm):
    event_id = SelectField("Event", coerce=int, validators=[DataRequired()])
    title = StringField("Opportunity title", validators=[DataRequired(), Length(max=200)])
    description = TextAreaField("Description", validators=[DataRequired(), Length(min=10, max=3000)])
    application_deadline = DateTimeLocalField("Application deadline", validators=[DataRequired()])
    reporting_instructions = TextAreaField("Reporting instructions (shown to accepted volunteers)", validators=[Optional(), Length(max=1500)])
    coordinator_info = StringField("Coordinator contact", validators=[Optional(), Length(max=255)])


class RoleForm(FlaskForm):
    name = StringField("Role name", validators=[DataRequired(), Length(max=120)])
    positions = IntegerField("Volunteers needed", validators=[DataRequired(), NumberRange(min=1, max=500)])
    description = TextAreaField("Role description", validators=[Optional(), Length(max=1500)])
    required_skills = TextAreaField("Required skills", validators=[Optional(), Length(max=1000)])
    eligibility = TextAreaField("Eligibility", validators=[Optional(), Length(max=1000)])


class ApplyForm(FlaskForm):
    skills = TextAreaField("Relevant skills", validators=[Optional(), Length(max=1000)])
    experience = TextAreaField("Experience", validators=[Optional(), Length(max=1000)])
    interests = TextAreaField("Interests", validators=[Optional(), Length(max=1000)])
    availability = TextAreaField("Availability", validators=[DataRequired(), Length(max=1000)])
    motivation = TextAreaField("Why do you want to volunteer?", validators=[DataRequired(), Length(min=20, max=1500)])
