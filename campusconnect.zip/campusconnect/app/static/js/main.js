(function () {
  var toggle = document.querySelector('.nav-toggle'), links = document.getElementById('nav-links');
  if (toggle && links) toggle.addEventListener('click', function () {
    var open = links.classList.toggle('open'); toggle.setAttribute('aria-expanded', open);
  });
  document.querySelectorAll('[data-menu]').forEach(function (btn) {
    var menu = document.getElementById(btn.dataset.menu);
    btn.addEventListener('click', function (e) { e.stopPropagation(); var o = menu.classList.toggle('open'); btn.setAttribute('aria-expanded', o); });
  });
  document.addEventListener('click', function () { document.querySelectorAll('.menu.open').forEach(function (m) { m.classList.remove('open'); }); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') document.querySelectorAll('.menu.open').forEach(function (m) { m.classList.remove('open'); }); });
  document.querySelectorAll('.flash button').forEach(function (b) { b.addEventListener('click', function () { b.parentElement.remove(); }); });
  // confirmation prompts for sensitive actions
  document.querySelectorAll('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) { if (!window.confirm(f.dataset.confirm)) e.preventDefault(); });
  });
  // loading state to prevent double submits
  document.querySelectorAll('form').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      if (e.defaultPrevented) return;
      var b = f.querySelector('button[type=submit]'); if (b) { b.disabled = true; b.dataset.label = b.textContent; b.textContent = 'Please wait…'; }
    });
  });
})();
