# CampusConnect

College event management and volunteer coordination website (Flask + MySQL).
**Status: Milestone 1 complete + student volunteering (core flow).** See the roadmap below; nothing is simulated.

Deploying online: see DEPLOY.md (free PythonAnywhere walkthrough).

## Features working now (Milestone 1)
- Public site: home (live DB statistics, featured events, categories), event search/filter/pagination, event details, About, Help, Privacy, Terms, custom 403/404/413/429/500 pages
- Student registration, organizer application, login/logout, profile editing
- Server-enforced roles (student / organizer / admin); organizers need admin approval
- Security: scrypt password hashing, CSRF on all forms, DB-backed login throttling, session invalidation on logout/suspension, open-redirect protection, secure cookie settings, security headers
- Admin: platform metrics, organizer approvals, user search + suspend/restore (with confirmation prompts), audit log
- Full relational schema (all 22 tables) with Alembic migrations

## Volunteering (working now)
- Students: browse/search/filter open roles, apply with skills/experience/availability/motivation, track status (Pending/Accepted/Waitlisted/Rejected/Withdrawn), withdraw before the deadline, re-apply after withdrawing, see reporting instructions once accepted.
- Organizers: create opportunities for their own published events, define roles with positions/skills/eligibility, review submissions, accept/waitlist/reject. Role capacity is enforced (row-locked) and applicants are notified in-app.
- Not built yet: shifts, check-in/out, verified hours, certificates, announcements.

## Sign-in portals
Students `/login`, organizers `/organizer/login`, admins `/admin/login`. Each portal only accepts its own role. Admins are not self-registered: `flask create-admin`.

## Roadmap (not built yet)
2. Event creation/approval, registration, capacity, waitlist  3. Tickets + QR check-in  4. Volunteer shifts, attendance, verified hours  5. Certificates + notifications center  6. Analytics (Chart.js), CSV exports, remaining admin tables

## Stack
Flask 3, SQLAlchemy 2, Flask-Migrate, Flask-WTF (CSRF), PyMySQL, pytest; custom CSS + vanilla JS.

## Architecture
`app/models` (schema) · `app/routes` (blueprints) · `app/services` (business logic, audit, notifications) · `app/forms` · `app/templates` · `app/static` · `tests` · `migrations`

## ER diagram
```mermaid
erDiagram
  COLLEGES ||--o{ USERS : has
  USERS ||--o| ORGANIZER_PROFILES : "applies as"
  CLUBS ||--o{ ORGANIZER_PROFILES : "belongs to"
  USERS ||--o{ EVENTS : organizes
  CATEGORIES ||--o{ EVENTS : classifies
  CLUBS ||--o{ EVENTS : hosts
  EVENTS ||--o{ EVENT_REGISTRATIONS : receives
  USERS ||--o{ EVENT_REGISTRATIONS : makes
  EVENT_REGISTRATIONS ||--o| TICKETS : issues
  EVENT_REGISTRATIONS ||--o| ATTENDANCE_RECORDS : "checked in"
  USERS ||--o{ SAVED_EVENTS : saves
  EVENTS ||--o{ SAVED_EVENTS : saved
  EVENTS ||--o{ VOLUNTEER_OPPORTUNITIES : offers
  VOLUNTEER_OPPORTUNITIES ||--o{ VOLUNTEER_ROLES : defines
  VOLUNTEER_ROLES ||--o{ VOLUNTEER_SHIFTS : schedules
  USERS ||--o{ VOLUNTEER_APPLICATIONS : submits
  VOLUNTEER_ROLES ||--o{ VOLUNTEER_APPLICATIONS : receives
  VOLUNTEER_APPLICATIONS ||--o| VOLUNTEER_ASSIGNMENTS : "becomes"
  VOLUNTEER_SHIFTS ||--o{ VOLUNTEER_ASSIGNMENTS : staffs
  VOLUNTEER_ASSIGNMENTS ||--o| VOLUNTEER_ATTENDANCE : records
  VOLUNTEER_ASSIGNMENTS ||--o| CERTIFICATES : earns
  USERS ||--o{ NOTIFICATIONS : receives
  EVENTS ||--o{ ANNOUNCEMENTS : has
  USERS ||--o{ AUDIT_LOGS : performs
```
Key constraints: unique `(event_id, user_id)` registrations, unique ticket/certificate references, one attendance row per registration/assignment, CHECK constraints on capacity, positions, and time ordering.

## Prerequisites
Python 3.10+, MySQL 8 (or MariaDB 10.6+), Git.

## Setup
```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                  # then edit SECRET_KEY and DATABASE_URL
```
MySQL:
```sql
CREATE DATABASE campusconnect CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'campus'@'localhost' IDENTIFIED BY 'choose-a-password';
GRANT ALL ON campusconnect.* TO 'campus'@'localhost';
```
Generate a secret: `python -c "import secrets; print(secrets.token_hex(32))"`

```bash
export FLASK_APP=run.py        # Windows: set FLASK_APP=run.py
flask db upgrade               # create tables
flask seed                     # optional demo data (refused when FLASK_ENV=production)
flask run                      # http://127.0.0.1:5000
```

## Demo accounts (seeded, local development only)
Password for all: `Demo@12345` — `admin@campusconnect.local`, `organizer@campusconnect.local`, `student@campusconnect.local`. Demo events are labelled "Demo".

## Tests
```bash
pytest -q                                   # uses in-memory SQLite
# against MySQL (create campusconnect_test first):
TEST_DATABASE_URL="mysql+pymysql://campus:PW@localhost/campusconnect_test?charset=utf8mb4" pytest -q
```

## Troubleshooting
- `SECRET_KEY is not set` / `DATABASE_URL is not set`: create `.env` from `.env.example`.
- `Access denied` from MySQL: recheck user/password/grants in `DATABASE_URL`.
- `cryptography` needed by PyMySQL for MySQL 8 `caching_sha2_password` (included in requirements).

## Known limitations
- No email delivery: password reset is administrator-assisted; notifications will be in-app only.
- No payments; the schema reserves `registration_type`/`price_cents` for the future.
- Login throttling is DB-backed per email+IP; add a reverse-proxy limiter in production.
- Screenshots: add after running locally.
