from datetime import timedelta
from app.extensions import db
from app.models import (Category, Event, VolunteerOpportunity, VolunteerRole, VolunteerApplication, Notification)
from app.utils import utcnow
from tests.conftest import login, make_user

APPLY = {"skills": "Python", "experience": "Hackathon helper", "interests": "Tech", "availability": "Weekends",
         "motivation": "I want to help run the event smoothly and learn."}


def setup_event(org, positions=1, deadline_days=2, status="published"):
    cat = Category.query.first() or Category(name="Sports", slug="sports")
    db.session.add(cat)
    db.session.flush()
    start = utcnow() + timedelta(days=5)
    ev = Event(title="Cup", description="d", category_id=cat.id, organizer_id=org.id, venue="Ground", start_at=start,
               end_at=start + timedelta(hours=3), registration_deadline=start, capacity=50, status=status)
    db.session.add(ev)
    db.session.flush()
    opp = VolunteerOpportunity(event_id=ev.id, title="Cup crew", description="Help run the cup",
                               application_deadline=utcnow() + timedelta(days=deadline_days))
    db.session.add(opp)
    db.session.flush()
    role = VolunteerRole(opportunity_id=opp.id, name="Registration Desk", positions=positions)
    db.session.add(role)
    db.session.commit()
    return ev, opp, role


def apply_as(app, email, role_id, data=APPLY):
    c = app.test_client()
    login(c, email)
    return c, c.post(f"/volunteer/roles/{role_id}/apply", data=data)


def test_student_applies_and_organizer_notified(app, users):
    _, _, role = setup_event(users["organizer"])
    c, r = apply_as(app, "s@test.com", role.id)
    assert r.status_code == 302
    a = VolunteerApplication.query.one()
    assert a.status == "pending" and a.user_id == users["student"].id
    assert Notification.query.filter_by(user_id=users["organizer"].id, kind="volunteer_application").count() == 1
    assert b"Registration Desk" in c.get("/volunteer/my-applications").data


def test_duplicate_application_blocked(app, users):
    _, _, role = setup_event(users["organizer"])
    c, _ = apply_as(app, "s@test.com", role.id)
    r = c.post(f"/volunteer/roles/{role.id}/apply", data=APPLY)
    assert b"already applied" in r.data
    assert VolunteerApplication.query.count() == 1


def test_deadline_and_unpublished_event_enforced(app, users):
    _, opp, role = setup_event(users["organizer"])
    opp.application_deadline = utcnow() - timedelta(hours=1)
    db.session.commit()
    c, r = apply_as(app, "s@test.com", role.id)
    assert b"deadline has passed" in r.data and VolunteerApplication.query.count() == 0
    ev2, _, role2 = setup_event(users["organizer"], status="draft")
    assert c.get(f"/volunteer/roles/{role2.id}/apply").status_code == 404


def test_validation_requires_motivation(app, users):
    _, _, role = setup_event(users["organizer"])
    _, r = apply_as(app, "s@test.com", role.id, {**APPLY, "motivation": "short"})
    assert r.status_code == 200 and VolunteerApplication.query.count() == 0


def test_role_capacity_enforced_on_accept(app, users):
    _, opp, role = setup_event(users["organizer"], positions=1)
    apply_as(app, "s@test.com", role.id)
    apply_as(app, "s2@test.com", role.id)
    org = app.test_client()
    login(org, "o@test.com")
    a1, a2 = VolunteerApplication.query.order_by(VolunteerApplication.id).all()
    org.post(f"/organizer/volunteer/applications/{a1.id}/decision", data={"decision": "accept"})
    r = org.post(f"/organizer/volunteer/applications/{a2.id}/decision", data={"decision": "accept"}, follow_redirects=True)
    assert b"All positions" in r.data
    db.session.expire_all()
    assert db.session.get(VolunteerApplication, a1.id).status == "accepted"
    assert db.session.get(VolunteerApplication, a2.id).status == "pending"
    org.post(f"/organizer/volunteer/applications/{a2.id}/decision", data={"decision": "waitlist"})
    db.session.expire_all()
    assert db.session.get(VolunteerApplication, a2.id).status == "waitlisted"
    assert Notification.query.filter_by(user_id=users["student"].id, kind="volunteer_decision").count() == 1


def test_accepted_student_sees_reporting_instructions(app, users):
    _, opp, role = setup_event(users["organizer"])
    opp.reporting_instructions = "Report to Gate 2 at 8am"
    db.session.commit()
    c, _ = apply_as(app, "s@test.com", role.id)
    org = app.test_client()
    login(org, "o@test.com")
    aid = VolunteerApplication.query.one().id
    assert b"Gate 2" not in c.get("/volunteer/my-applications").data
    org.post(f"/organizer/volunteer/applications/{aid}/decision", data={"decision": "accept"})
    assert b"Gate 2" in c.get("/volunteer/my-applications").data


def test_withdraw_and_reapply_and_idor(app, users):
    _, _, role = setup_event(users["organizer"])
    c, _ = apply_as(app, "s@test.com", role.id)
    aid = VolunteerApplication.query.one().id
    other = app.test_client()
    login(other, "s2@test.com")
    assert other.post(f"/volunteer/applications/{aid}/withdraw").status_code == 404
    assert c.post(f"/volunteer/applications/{aid}/withdraw").status_code == 302
    db.session.expire_all()
    assert db.session.get(VolunteerApplication, aid).status == "withdrawn"
    c.post(f"/volunteer/roles/{role.id}/apply", data=APPLY)
    db.session.expire_all()
    assert VolunteerApplication.query.count() == 1 and db.session.get(VolunteerApplication, aid).status == "pending"


def test_withdraw_blocked_after_deadline(app, users):
    _, opp, role = setup_event(users["organizer"])
    c, _ = apply_as(app, "s@test.com", role.id)
    opp.application_deadline = utcnow() - timedelta(minutes=1)
    db.session.commit()
    aid = VolunteerApplication.query.one().id
    c.post(f"/volunteer/applications/{aid}/withdraw")
    db.session.expire_all()
    assert db.session.get(VolunteerApplication, aid).status == "pending"


def test_other_organizer_cannot_view_or_decide(app, users):
    other_org = make_user("o2@test.com", "organizer")
    _, opp, role = setup_event(users["organizer"])
    apply_as(app, "s@test.com", role.id)
    aid = VolunteerApplication.query.one().id
    c = app.test_client()
    login(c, "o2@test.com")
    assert c.get(f"/organizer/volunteer/{opp.id}").status_code == 404
    assert c.post(f"/organizer/volunteer/applications/{aid}/decision", data={"decision": "accept"}).status_code == 404
    assert c.post(f"/organizer/volunteer/{opp.id}/roles", data={"name": "x", "positions": 2}).status_code == 404


def test_role_gates_on_volunteer_pages(app, users):
    _, _, role = setup_event(users["organizer"])
    s = app.test_client()
    login(s, "s@test.com")
    for url in ("/organizer/volunteer/", "/organizer/volunteer/new"):
        assert s.get(url).status_code == 403
    o = app.test_client()
    login(o, "o@test.com")
    assert o.get(f"/volunteer/roles/{role.id}/apply").status_code == 403
    assert o.get("/volunteer/my-applications").status_code == 403


def test_organizer_creates_opportunity_and_role_for_own_event_only(app, users):
    ev, _, _ = setup_event(users["organizer"])
    other_org = make_user("o2@test.com", "organizer")
    o = app.test_client()
    login(o, "o@test.com")
    deadline = (utcnow() + timedelta(days=1)).strftime("%Y-%m-%dT%H:%M")
    data = {"event_id": ev.id, "title": "Ushers", "description": "Guide guests to seats", "application_deadline": deadline}
    r = o.post("/organizer/volunteer/new", data=data)
    assert r.status_code == 302
    opp = VolunteerOpportunity.query.filter_by(title="Ushers").one()
    o.post(f"/organizer/volunteer/{opp.id}/roles", data={"name": "Usher", "positions": 3})
    assert VolunteerRole.query.filter_by(name="Usher").one().positions == 3
    o2 = app.test_client()
    login(o2, "o2@test.com")
    r = o2.post("/organizer/volunteer/new", data=data)
    assert r.status_code == 200 and VolunteerOpportunity.query.filter_by(title="Ushers").count() == 1
    late = (ev.end_at + timedelta(days=1)).strftime("%Y-%m-%dT%H:%M")
    r = o.post("/organizer/volunteer/new", data={**data, "title": "Late", "application_deadline": late})
    assert b"before the event ends" in r.data


def test_volunteer_hub_search_filter_and_stats(app, users):
    _, _, role = setup_event(users["organizer"])
    c = app.test_client()
    assert b"Registration Desk" in c.get("/volunteer/").data
    assert b"Registration Desk" in c.get("/volunteer/?q=desk").data
    assert b"Registration Desk" not in c.get("/volunteer/?q=zzzz").data
    s, _ = apply_as(app, "s@test.com", role.id)
    assert b"Pending" in s.get("/volunteer/").data
    o = app.test_client()
    login(o, "o@test.com")
    assert b"0/1" in o.get("/dashboard/organizer").data
