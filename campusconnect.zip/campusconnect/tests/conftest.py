import pytest
from app import create_app
from app.extensions import db
from app.models import User, OrganizerProfile, College
from config import TestConfig


@pytest.fixture()
def app():
    app = create_app(TestConfig)
    with app.app_context():
        db.drop_all()
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture()
def client(app):
    return app.test_client()


def make_user(email, role="student", password="Passw0rdX", active=True, org_status=None):
    college = College.query.first() or College(name="Test College")
    u = User(name=f"{role.title()} Tester", email=email, role=role, college=college,
             course="CSE", year=2, is_active_account=active)
    u.set_password(password)
    db.session.add(u)
    db.session.flush()
    if role == "organizer":
        db.session.add(OrganizerProfile(user_id=u.id, club_name="Test Club", reason="x" * 30,
                                        status=org_status or "approved"))
    db.session.commit()
    return u


PORTAL = {"student": "/login", "organizer": "/organizer/login", "admin": "/admin/login"}


def login(client, email, password="Passw0rdX"):
    role = User.query.filter_by(email=email).one().role
    return client.post(PORTAL[role], data={"email": email, "password": password}, follow_redirects=False)


@pytest.fixture()
def users(app):
    return {
        "student": make_user("s@test.com"),
        "other": make_user("s2@test.com"),
        "organizer": make_user("o@test.com", "organizer"),
        "pending_org": make_user("po@test.com", "organizer", org_status="pending"),
        "admin": make_user("a@test.com", "admin"),
    }
