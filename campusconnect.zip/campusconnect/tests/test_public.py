from datetime import timedelta
from app.extensions import db
from app.models import Category, Event, Club
from app.utils import utcnow
from tests.conftest import make_user


def _event(org, cat, title, status="published"):
    start = utcnow() + timedelta(days=3)
    e = Event(title=title, description="d", category_id=cat.id, organizer_id=org.id, venue="Hall",
              start_at=start, end_at=start + timedelta(hours=2), registration_deadline=start, capacity=10, status=status)
    db.session.add(e)
    db.session.commit()
    return e


def test_public_pages_render_and_only_published_events_visible(client, app):
    org = make_user("o@test.com", "organizer")
    cat = Category(name="Sports", slug="sports")
    db.session.add(cat)
    db.session.commit()
    pub = _event(org, cat, "Visible Cup")
    draft = _event(org, cat, "Secret Draft", status="draft")
    for url in ("/", "/events", "/about", "/help", "/privacy", "/terms", "/login", "/register", "/organizer-application"):
        assert client.get(url).status_code == 200, url
    assert b"Visible Cup" in client.get("/events").data
    assert b"Secret Draft" not in client.get("/events").data
    assert client.get(f"/events/{pub.id}").status_code == 200
    assert client.get(f"/events/{draft.id}").status_code == 404


def test_event_search_filter_and_custom_404(client, app):
    org = make_user("o@test.com", "organizer")
    a, b = Category(name="Sports", slug="sports"), Category(name="Seminars", slug="seminars")
    db.session.add_all([a, b])
    db.session.commit()
    _event(org, a, "Cricket Cup")
    _event(org, b, "Data Talk")
    assert b"Cricket Cup" in client.get("/events?q=cricket").data
    assert b"Data Talk" not in client.get("/events?q=cricket").data
    assert b"Data Talk" in client.get("/events?category=seminars").data
    assert b"Cricket Cup" not in client.get("/events?category=seminars").data
    r = client.get("/nope")
    assert r.status_code == 404 and b"Page not found" in r.data


def test_homepage_stats_come_from_database(client, app):
    make_user("s@test.com")
    make_user("s2@test.com")
    html = client.get("/").data.decode()
    assert '<b>2</b><span>Students</span>' in html
