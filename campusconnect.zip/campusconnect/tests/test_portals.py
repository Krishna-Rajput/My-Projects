from tests.conftest import login


def _post(client, path, email):
    return client.post(path, data={"email": email, "password": "Passw0rdX"})


def test_each_portal_accepts_only_its_own_role(client, users):
    for path, email, wrong in (("/login", "s@test.com", "o@test.com"), ("/organizer/login", "o@test.com", "s@test.com"),
                               ("/admin/login", "a@test.com", "s@test.com")):
        assert _post(client, path, wrong).status_code == 200  # rejected, no redirect
        with client.session_transaction() as s:
            assert "uid" not in s
        assert _post(client, path, email).status_code == 302
        client.post("/logout")


def test_wrong_portal_message_only_after_correct_password(client, users):
    r = client.post("/admin/login", data={"email": "s@test.com", "password": "wrong"})
    assert b"Incorrect email or password" in r.data and b"student account" not in r.data
    r = _post(client, "/admin/login", "s@test.com")
    assert b"student account" in r.data


def test_unauthenticated_redirects_go_to_matching_portal(client):
    assert "/admin/login" in client.get("/admin/").headers["Location"]
    assert "/organizer/login" in client.get("/dashboard/organizer").headers["Location"]
    assert "/organizer/login" in client.get("/organizer/volunteer/").headers["Location"]
    assert "/login" in client.get("/volunteer/my-applications").headers["Location"]


def test_portal_pages_render_and_admin_has_no_signup_link(client):
    for p in ("/login", "/organizer/login", "/admin/login"):
        assert client.get(p).status_code == 200
    assert b"Create a student account" not in client.get("/admin/login").data
    assert b"CampusConnect" in client.get("/").data and b"hero-title" in client.get("/").data
