from app.extensions import db
from app.models import User, OrganizerProfile, AuditLog, LoginAttempt
from tests.conftest import login, make_user

REG = {"name": "New Student", "email": "new@test.com", "college": "Test College", "course": "CSE",
       "year": "2", "password": "Passw0rdX", "confirm": "Passw0rdX"}


def test_student_registration_hashes_password_and_logs_in(client):
    r = client.post("/register", data=REG)
    assert r.status_code == 302
    u = User.query.filter_by(email="new@test.com").first()
    assert u and u.role == "student"
    assert u.password_hash != "Passw0rdX" and u.check_password("Passw0rdX")
    assert client.get("/dashboard/student").status_code == 200


def test_duplicate_email_rejected_case_insensitive(client):
    client.post("/register", data=REG)
    client.post("/logout")
    r = client.post("/register", data={**REG, "email": "NEW@test.com"})
    assert r.status_code == 200 and b"already exists" in r.data
    assert User.query.filter_by(email="new@test.com").count() == 1


def test_weak_password_and_mismatch_rejected(client):
    r = client.post("/register", data={**REG, "password": "onlyletters", "confirm": "onlyletters"})
    assert b"letter and one number" in r.data
    r = client.post("/register", data={**REG, "confirm": "Different1"})
    assert b"Passwords must match" in r.data
    assert User.query.count() == 0


def test_login_logout_flow(client, users):
    assert login(client, "s@test.com").status_code == 302
    assert client.get("/dashboard/student").status_code == 200
    assert client.post("/logout").status_code == 302
    assert client.get("/dashboard/student").status_code == 302  # redirected to login


def test_wrong_password_generic_message(client, users):
    r = client.post("/login", data={"email": "s@test.com", "password": "nope"})
    assert b"Incorrect email or password" in r.data
    r = client.post("/login", data={"email": "ghost@test.com", "password": "nope"})
    assert b"Incorrect email or password" in r.data


def test_login_throttling_after_repeated_failures(client, users):
    for _ in range(5):
        client.post("/login", data={"email": "s@test.com", "password": "bad"})
    r = client.post("/login", data={"email": "s@test.com", "password": "Passw0rdX"})
    assert b"Too many failed attempts" in r.data
    assert client.get("/dashboard/student").status_code == 302


def test_logout_invalidates_copied_session_cookie(app, users):
    c1, c2 = app.test_client(), app.test_client()
    login(c1, "s@test.com")
    with c1.session_transaction() as s:
        stolen = dict(s)
    c1.post("/logout")
    with c2.session_transaction() as s:
        s.update(stolen)
    assert c2.get("/dashboard/student").status_code == 302


def test_suspended_user_cannot_login_or_keep_session(client, app, users):
    login(client, "s@test.com")
    admin = app.test_client()
    login(admin, "a@test.com")
    assert admin.post(f"/admin/users/{users['student'].id}/toggle-active").status_code == 302
    assert client.get("/dashboard/student").status_code == 302
    r = client.post("/login", data={"email": "s@test.com", "password": "Passw0rdX"})
    assert b"suspended" in r.data
    assert AuditLog.query.filter_by(action="user_suspended").count() == 1


def test_open_redirect_blocked(client, users):
    r = client.post("/login?next=//evil.com", data={"email": "s@test.com", "password": "Passw0rdX"})
    assert r.status_code == 302 and "evil.com" not in r.headers["Location"]
