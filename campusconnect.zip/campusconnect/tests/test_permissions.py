from app.extensions import db
from app.models import OrganizerProfile, Club, AuditLog, User
from tests.conftest import login

ORG_APPLY = {"name": "Org Person", "email": "org@test.com", "college": "Test College", "course": "CSE", "year": "3",
             "password": "Passw0rdX", "confirm": "Passw0rdX", "club_name": "Robotics Club",
             "reason": "We run weekly robotics workshops for juniors."}


def test_anonymous_redirected_from_protected_pages(client):
    for url in ("/dashboard", "/dashboard/student", "/admin/", "/admin/users", "/profile"):
        r = client.get(url)
        assert r.status_code == 302 and "/login" in r.headers["Location"], url


def test_student_forbidden_from_admin_and_organizer(client, users):
    login(client, "s@test.com")
    for url in ("/admin/", "/admin/users", "/admin/organizers", "/admin/audit-logs", "/dashboard/organizer"):
        assert client.get(url).status_code == 403, url
    assert client.post("/admin/users/1/toggle-active").status_code == 403


def test_admin_forbidden_from_student_dashboard_and_organizer_forbidden_from_admin(client, app, users):
    login(client, "o@test.com")
    assert client.get("/admin/").status_code == 403
    assert client.get("/dashboard/organizer").status_code == 200
    admin = app.test_client()
    login(admin, "a@test.com")
    assert admin.get("/dashboard/student").status_code == 403
    assert admin.get("/admin/").status_code == 200


def test_pending_organizer_cannot_use_organizer_area(client, users):
    login(client, "po@test.com")
    r = client.get("/dashboard/organizer")
    assert r.status_code == 302 and "pending" in r.headers["Location"]
    assert client.get("/dashboard/organizer/pending").status_code == 200


def test_organizer_application_then_admin_approval(client, app):
    assert client.post("/organizer-application", data=ORG_APPLY).status_code == 302
    u = User.query.filter_by(email="org@test.com").one()
    assert u.role == "organizer" and u.organizer_profile.status == "pending"
    assert client.get("/dashboard/organizer").status_code == 302

    from tests.conftest import make_user
    make_user("adm@test.com", "admin")
    admin = app.test_client()
    login(admin, "adm@test.com")
    pid = u.organizer_profile.id
    assert admin.post(f"/admin/organizers/{pid}/decision", data={"decision": "approve"}).status_code == 302
    assert u.organizer_profile.status == "approved" and Club.query.filter_by(name="Robotics Club").count() == 1
    assert AuditLog.query.filter_by(action="organizer_approved").count() == 1
    assert client.get("/dashboard/organizer").status_code == 200


def test_organizer_rejection_blocks_access(client, app):
    client.post("/organizer-application", data=ORG_APPLY)
    from tests.conftest import make_user
    make_user("adm@test.com", "admin")
    admin = app.test_client()
    login(admin, "adm@test.com")
    pid = User.query.filter_by(email="org@test.com").one().organizer_profile.id
    admin.post(f"/admin/organizers/{pid}/decision", data={"decision": "reject"})
    assert client.get("/dashboard/organizer").status_code == 302


def test_invalid_decision_value_rejected(client, users):
    login(client, "a@test.com")
    pid = users["pending_org"].organizer_profile.id
    assert client.post(f"/admin/organizers/{pid}/decision", data={"decision": "x"}).status_code == 400


def test_admin_cannot_suspend_self(client, users):
    login(client, "a@test.com")
    client.post(f"/admin/users/{users['admin'].id}/toggle-active")
    assert db.session.get(User, users["admin"].id).is_active_account is True


def test_csrf_enforced_when_enabled(app, users):
    app.config["WTF_CSRF_ENABLED"] = True
    c = app.test_client()
    r = c.post("/login", data={"email": "s@test.com", "password": "Passw0rdX"})
    assert r.status_code == 400


def test_admin_pages_render_with_real_data(client, users):
    login(client, "a@test.com")
    for url in ("/admin/", "/admin/organizers", "/admin/organizers?status=approved", "/admin/users",
                "/admin/users?q=tester", "/admin/audit-logs", "/profile"):
        assert client.get(url).status_code == 200, url
    assert b"Pending event approvals" in client.get("/admin/").data


def test_profile_update_persists(client, users):
    login(client, "s@test.com")
    r = client.post("/profile", data={"name": "Renamed", "college": "Other College", "course": "ECE", "year": "4"})
    assert r.status_code == 302
    u = db.session.get(User, users["student"].id)
    assert u.name == "Renamed" and u.year == 4 and u.college.name == "Other College"
