"""Production entry point (PythonAnywhere, gunicorn, etc.)."""
from app import create_app

application = create_app()
app = application
