import os
from datetime import timedelta
from dotenv import load_dotenv

load_dotenv()


_ENV = os.environ.get("FLASK_ENV", "development")


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY")
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {"pool_pre_ping": True}
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.environ.get("SESSION_COOKIE_SECURE", "1" if _ENV == "production" else "0") == "1"
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)
    MAX_CONTENT_LENGTH = 2 * 1024 * 1024  # 2 MB upload cap
    WTF_CSRF_TIME_LIMIT = 3600
    LOGIN_MAX_FAILURES = 5
    LOGIN_WINDOW_MINUTES = 15
    EMAIL_ENABLED = bool(os.environ.get("MAIL_SERVER"))
    ENV_NAME = _ENV


class TestConfig(Config):
    TESTING = True
    SECRET_KEY = "test-secret"
    SQLALCHEMY_DATABASE_URI = os.environ.get("TEST_DATABASE_URL") or "sqlite:///:memory:"
    SQLALCHEMY_ENGINE_OPTIONS = {}
    WTF_CSRF_ENABLED = False
    SERVER_NAME = None
