# Put CampusConnect online (free): PythonAnywhere

Result: a public link like `https://YOURNAME.pythonanywhere.com` with HTTPS and a MySQL database, free.

1. **Sign up** at pythonanywhere.com (free "Beginner" account). Your username becomes your link.
2. **Upload** `campusconnect.zip` (Files tab, upload to your home folder). Open a **Bash console** (Consoles tab):
   ```
   unzip campusconnect.zip && cd campusconnect
   mkvirtualenv campusenv --python=python3.10     # or any 3.10+ version offered
   pip install -r requirements.txt
   ```
3. **Database** (Databases tab): set a MySQL password (use letters and digits only), then create a database named `campusconnect`. Its full name is `YOURNAME$campusconnect`; the host is `YOURNAME.mysql.pythonanywhere-services.com`.
4. **Settings file**: in the console run `nano .env` and paste (use single quotes, fill in your values):
   ```
   FLASK_ENV=production
   SECRET_KEY='paste-a-long-random-string'
   DATABASE_URL='mysql+pymysql://YOURNAME:DBPASSWORD@YOURNAME.mysql.pythonanywhere-services.com/YOURNAME$campusconnect?charset=utf8mb4'
   ```
   Generate the key with `python -c "import secrets; print(secrets.token_hex(32))"`. Save with Ctrl+O, Enter, Ctrl+X.
5. **Create tables and your admin** (same console):
   ```
   export FLASK_APP=run.py
   flask db upgrade
   flask create-admin          # your real admin login
   flask seed                  # optional: demo events (prints random demo passwords)
   ```
6. **Web tab** → *Add a new web app* → *Manual configuration* → same Python version.
   - Source code and working directory: `/home/YOURNAME/campusconnect`
   - Virtualenv: `/home/YOURNAME/.virtualenvs/campusenv`
   - Click the WSGI configuration file link, delete everything, paste:
     ```
     import sys
     path = '/home/YOURNAME/campusconnect'
     if path not in sys.path:
         sys.path.insert(0, path)
     from wsgi import application
     ```
   - Static files: URL `/static/` → `/home/YOURNAME/campusconnect/app/static`
7. Click **Reload**, then open `https://YOURNAME.pythonanywhere.com`. Admin sign-in is at `/admin/login`.

**Notes**
- Free accounts must press "Run until 3 months from today" on the Web tab every few months or the site is disabled.
- Free accounts allow one web app and no custom domain.
- After updating code: upload, run `flask db upgrade` if the database changed, then Reload.
- Other hosts (Railway, Render, a VPS) also work: the `Procfile` runs `gunicorn wsgi:application`; you need a MySQL database and the same three environment variables.
